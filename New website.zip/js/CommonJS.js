﻿function fn_AddProductURL(productName,QtyID) {
    localStorage.clear();
    localStorage.setItem("productName", productName);
    localStorage.setItem("URL", window.location.href);
    if (!isNullOrEmpty(QtyID))
        localStorage.setItem("QTY", QtyID.value);
}
function isNullOrEmpty(value) {
    return typeof value === 'undefined' || value === null || value === '';
}