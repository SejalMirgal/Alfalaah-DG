﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class enquiry : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string Body = "<table border='1' style='border-collapse: collapse;border: 1px solid black;'>";
        Body += String.Format("<tr><td>Name</td><td>{0}</td></tr><tr><td>Phone</td><td>{1}</td></tr><tr><td>Ask Price</td><td>{2}</td></tr><tr><td>Email</td><td>{3}</td></tr><tr><td>Nature</td><td>{4}</td></tr><tr><td>Message</td><td>{5}</td></tr>", txtFirstName.Text, txtMobile.Text, txtPrice.Text, txtEmail.Text, ddlnature.SelectedValue,txtMessage.Text);
        if(!string.IsNullOrEmpty(hdproduct.Value))
        {
            Body += "<tr><td>Product Name</td><td>" + hdproduct.Value + "</td></tr>";
        }
        if (!string.IsNullOrEmpty(hdQty.Value))
        {
            Body += "<tr><td>Qty.</td><td>" + hdQty.Value + "</td></tr>";
        }
        if (!string.IsNullOrEmpty(hdURL.Value))
        {
            Body += "<tr><td>URL</td><td>" + hdURL.Value + "</td></tr>";
        }        
        Body += "</table>";
        string Sub = "Online enquiry on website";
        string retst = SendMail(Body, Sub);
        if (retst == "send")
        {
            clearform();
            Response.Write("<script language='javascript'>alert('Enquiry sent!');</script>");
            return;
        }
        else
        {
            clearform();
            Response.Write("<script language='javascript'>alert('" + retst + "');</script>");
            return;
        }
    }
    private void clearform()
    {
        txtFirstName.Text = string.Empty;
        txtPrice.Text = string.Empty;
        txtEmail.Text = string.Empty;
        ddlnature.SelectedIndex = -1;
        txtMobile.Text = string.Empty;
        txtMessage.Text = string.Empty;
        hdproduct.Value = string.Empty;
        hdURL.Value = string.Empty;
        hdQty.Value = string.Empty;
    }
    private string SendMail(string Body, string Subject)
    {
        try
        {
            string EmailHost = ConfigurationManager.AppSettings["smtphost"];
            string EmailPort = ConfigurationManager.AppSettings["smtpport"];
            string EmailUser = ConfigurationManager.AppSettings["username"];
            string EmailPassword = ConfigurationManager.AppSettings["pwd"];
            string fromEmail = ConfigurationManager.AppSettings["FromEmail"];
            string toEmail = ConfigurationManager.AppSettings["emailto"];
            SmtpClient client = new SmtpClient(EmailHost);
            MailMessage message = new MailMessage(fromEmail, toEmail);
            message.IsBodyHtml = true;
            message.Body = Body;
            message.Subject = Subject;
            client.Port = System.Convert.ToInt32(EmailPort);
            client.UseDefaultCredentials = false;
            client.Credentials = new System.Net.NetworkCredential(EmailUser, EmailPassword);
            client.EnableSsl = true;
            client.Send(message);
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
        return "send";
    }
}